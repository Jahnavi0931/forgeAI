import json, os, sqlite3, uuid, tempfile
from datetime import datetime, timezone
from typing import Optional

import joblib
import numpy as np
from PIL import Image
from skimage.feature import hog
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL = joblib.load(os.path.join(BASE, 'defect_classifier.joblib'))
with open(os.path.join(BASE, 'model_metadata.json'), 'r') as f:
    META = json.load(f)
CLASSES = META['classes']
STATIC = os.path.join(BASE, 'static')   # the built React app (one URL: site + API)


def _pick_db_path():
    """DB_PATH env var wins; otherwise next to main.py; fall back to the temp dir if that is read-only."""
    wanted = os.environ.get('DB_PATH') or os.path.join(BASE, 'quality_to_cash.db')
    try:
        os.makedirs(os.path.dirname(wanted), exist_ok=True)
        sqlite3.connect(wanted).close()
        return wanted
    except Exception:
        return os.path.join(tempfile.gettempdir(), 'quality_to_cash.db')


DB = _pick_db_path()

app = FastAPI(title='Quality-to-Cash Control Room API', version='1.0.0')
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'], allow_credentials=False,
    allow_methods=['*'], allow_headers=['*']
)

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

with db() as con:
    con.execute('''CREATE TABLE IF NOT EXISTS inspections (
        id TEXT PRIMARY KEY, filename TEXT NOT NULL, predicted_class TEXT NOT NULL,
        confidence REAL NOT NULL, created_at TEXT NOT NULL
    )''')
    con.commit()

def predict_image(path):
    im = np.array(Image.open(path).convert('L').resize(tuple(META['input_size'])))
    feat = hog(im, orientations=META['orientations'],
               pixels_per_cell=tuple(META['pixels_per_cell']),
               cells_per_block=tuple(META['cells_per_block']),
               block_norm='L2-Hys').reshape(1, -1)
    scores = MODEL.decision_function(feat)[0]
    ex = np.exp(scores - scores.max())
    conf = ex / ex.sum()
    order = np.argsort(-conf)
    return [{'class': CLASSES[i], 'confidence': round(float(conf[i]), 4)} for i in order]

@app.get('/api')
def api_root():
    return {'name': 'Quality-to-Cash Control Room API', 'status': 'online', 'docs': '/docs'}

@app.get('/health')
@app.get('/api/health')
def health():
    return {'status': 'healthy', 'model': META.get('model'), 'classes': CLASSES,
            'frontend_served': os.path.isdir(STATIC)}

@app.get('/api/model')
def model_info():
    return META


@app.post('/api/analyze-image')
async def analyze_image(payload: dict):
    """Compatibility endpoint used by the existing React control room."""
    image_b64 = payload.get('imageBase64', '')
    if not image_b64:
        raise HTTPException(400, 'Missing imageBase64.')
    import base64
    import re
    clean = re.sub(r'^data:image/[^;]+;base64,', '', image_b64)
    try:
        data = base64.b64decode(clean)
    except Exception:
        raise HTTPException(400, 'Invalid base64 image.')
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, 'Image is larger than 10 MB.')
    fd, path = tempfile.mkstemp(suffix='.jpg')
    os.close(fd)
    try:
        with open(path, 'wb') as f:
            f.write(data)
        results = predict_image(path)
    except Exception as e:
        raise HTTPException(422, f'Could not process image: {e}')
    finally:
        if os.path.exists(path):
            os.remove(path)

    top = results[0]
    # The model confidence is a relative score derived from LinearSVC scores,
    # not a calibrated probability.
    defect = top['class']
    verdict = 'Acceptable' if defect == 'normal' else 'Defective'
    severity = 0 if defect == 'normal' else (3 if top['confidence'] >= 0.55 else 2)
    boxes = [] if defect == 'normal' else [{
        'label': defect,
        'box_2d': [250, 250, 750, 750]
    }]
    cues = ['HOG/LinearSVC visual classification']
    if defect != 'normal':
        cues.append(f'Model classified the image as {defect}.')
    return {
        'source': 'local-linearSVC',
        'verdict': verdict,
        'defect_type': defect,
        'defectType': defect,
        'matches_known_class': True,
        'severity': severity,
        'confidence': round(top['confidence'] * 100, 2),
        'uncertaintyScore': round((1 - top['confidence']) * 100, 2),
        'isAnomalyNovelty': False,
        'boxes': boxes,
        'visual_cues': cues,
        'visualCues': cues,
        'results': results
    }

@app.post('/api/generate-advice')
async def generate_advice(payload: dict):
    # Deterministic advice keeps the app functional without a paid AI key.
    e = payload.get('evidenceNumbers') or payload.get('evidence') or {}
    cutoff = e.get('optimalCutoff', 0.26)
    return {
        'source': 'rule-synthesis',
        'recommendations': [
            {
                'id': 'rec-api-1',
                'title': 'Inspect the highest-risk production station',
                'category': 'Process Control',
                'action': 'Review the station with the highest defect rate and compare its process telemetry with baseline values.',
                'expectedImpact': 'Prioritizes investigation using the evidence already visible in the control room.',
                'evidenceNumbers': f"QIS={e.get('qisScore', 'n/a')}; bottleneck cycle={e.get('bottleneckCycle', 'n/a')}s.",
                'confidence': 'Evidence-based rule'
            },
            {
                'id': 'rec-api-2',
                'title': 'Use cost-aware review thresholds',
                'category': 'Decision Policy',
                'action': f'Set the operational review/reject cutoff using the supplied cost model; current calculated optimal cutoff is {float(cutoff):.3f}.',
                'expectedImpact': 'Makes the accept/reject policy explicitly account for false-reject and missed-defect costs.',
                'evidenceNumbers': f"False-reject cost={e.get('costFalseReject', 'n/a')}; missed-defect cost={e.get('costMissedDefect', 'n/a')}.",
                'confidence': 'Mathematical rule'
            }
        ]
    }

@app.post('/api/predict')
async def predict(file: UploadFile = File(...)):
    if not file.content_type or not file.content_type.startswith('image/'):
        raise HTTPException(400, 'Please upload an image file.')
    data = await file.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, 'Image is larger than 10 MB.')
    suffix = os.path.splitext(file.filename or '')[1] or '.jpg'
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.close(fd)
    try:
        with open(path, 'wb') as f: f.write(data)
        results = predict_image(path)
    except Exception as e:
        raise HTTPException(422, f'Could not process image: {e}')
    finally:
        if os.path.exists(path): os.remove(path)
    top = results[0]
    record_id = str(uuid.uuid4())
    created = datetime.now(timezone.utc).isoformat()
    with db() as con:
        con.execute('INSERT INTO inspections VALUES (?, ?, ?, ?, ?)',
                    (record_id, file.filename or 'image', top['class'], top['confidence'], created))
        con.commit()
    return {'id': record_id, 'filename': file.filename, 'prediction': top, 'results': results, 'created_at': created}

@app.get('/api/inspections')
def inspections(limit: int = 50):
    limit = max(1, min(limit, 200))
    with db() as con:
        rows = con.execute('SELECT * FROM inspections ORDER BY created_at DESC LIMIT ?', (limit,)).fetchall()
    return [dict(r) for r in rows]

@app.get('/api/summary')
def summary():
    with db() as con:
        total = con.execute('SELECT COUNT(*) FROM inspections').fetchone()[0]
        rows = con.execute('SELECT predicted_class, COUNT(*) n FROM inspections GROUP BY predicted_class').fetchall()
    counts = {r['predicted_class']: r['n'] for r in rows}
    return {'total_inspections': total, 'by_class': counts, 'classes': CLASSES}


# ---------------------------------------------------------------------------
# One URL: serve the built React app from the same server.
# These routes are registered LAST so every /api/*, /docs and /health route wins.
# ---------------------------------------------------------------------------
if os.path.isdir(os.path.join(STATIC, 'assets')):
    app.mount('/assets', StaticFiles(directory=os.path.join(STATIC, 'assets')), name='assets')


@app.get('/', include_in_schema=False)
def index():
    idx = os.path.join(STATIC, 'index.html')
    if os.path.isfile(idx):
        return FileResponse(idx, headers={'Cache-Control': 'no-cache'})
    return {'name': 'Quality-to-Cash Control Room API', 'status': 'online', 'docs': '/docs',
            'note': 'Frontend not built: put the Vite build output in backend/static.'}


@app.get('/{full_path:path}', include_in_schema=False)
def spa_fallback(full_path: str):
    if full_path.startswith('api/'):
        return JSONResponse({'detail': 'Not found'}, status_code=404)
    root = os.path.realpath(STATIC)
    candidate = os.path.realpath(os.path.join(root, full_path))
    if candidate.startswith(root + os.sep) and os.path.isfile(candidate):
        return FileResponse(candidate)
    idx = os.path.join(root, 'index.html')
    if os.path.isfile(idx):
        return FileResponse(idx, headers={'Cache-Control': 'no-cache'})
    return JSONResponse({'detail': 'Not found'}, status_code=404)
