# Quality-to-Cash Control Room - backend (also serves the website)

FastAPI + the supplied HOG / LinearSVC defect classifier. If a `static/` folder is present
(the built React app), the same server shows the website at `/` - one URL for everything.

## Routes
- `GET /`                 the website (React app) - or a JSON status page if `static/` is missing
- `GET /health`, `/api/health`
- `POST /api/analyze-image`   JSON `{imageBase64, knownClasses, fewShotCorrections}`  (used by the app)
- `POST /api/generate-advice` JSON `{evidenceNumbers}`                                 (used by the app)
- `POST /api/predict`         multipart field `file`, stores the result in SQLite
- `GET /api/inspections?limit=50`, `GET /api/summary`, `GET /api/model`
- `GET /docs`             interactive API docs

## Run locally
```bash
pip install -r requirements.txt
uvicorn main:app --reload
# open http://127.0.0.1:8000  (site)  and  http://127.0.0.1:8000/docs  (API)
```

## Environment variables
- `DB_PATH`  where the SQLite history file lives (default: next to main.py, falls back to the temp folder)
- `PORT`     set by the host
