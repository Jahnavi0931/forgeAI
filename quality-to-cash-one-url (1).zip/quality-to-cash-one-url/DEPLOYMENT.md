# Quality-to-Cash Control Room - ONE URL deployment

```
Browser --> https://<your-service>.onrender.com
              |-- /            React app (built files in backend/static)
              |-- /api/...     FastAPI + HOG/LinearSVC model + SQLite history
              |-- /docs        API docs
```
The React app calls `/api/...` on the SAME address, so there is no CORS setup and no second URL.

## Option A - Render, from source (Docker, builds the website for you)
1. Push this whole folder to a GitHub repository.
2. Render -> New -> Blueprint (or Web Service -> Docker) -> pick the repo. `render.yaml` does the rest.
3. Wait for the build. Open the URL Render gives you. Check `<url>/health`.

## Option B - Render, without Docker (uses the already-built website in backend/static)
1. Push the folder to GitHub.
2. Render -> New -> Web Service -> pick the repo.
3. Root Directory: `backend`
   Build Command: `pip install -r requirements.txt`
   Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Health check path: `/health`

## Option C - Google Cloud Run
`gcloud run deploy quality-to-cash --source . --allow-unauthenticated --region asia-south1`
(uses the Dockerfile in this folder)

## After you change the frontend
Rebuild and copy the site into the backend, then redeploy:
```bash
npm install
npx vite build
rm -rf backend/static && cp -r dist backend/static
```
(Docker / Option A does this automatically on every deploy.)

## Things to know
- Free hosts sleep when idle: the first request after a break can take about a minute.
- The SQLite history file is stored on the server's disk. On free plans that disk is wiped on every
  redeploy or restart, so history is temporary. Use a persistent disk or an external database if it must last.
- Do not deploy this to Vercel: scikit-learn + scikit-image are too large for its serverless size limit,
  and serverless has no writable disk for SQLite.
- The model's "confidence" is a relative score from LinearSVC decision values, not a calibrated probability.
  Its reported validation accuracy is 76.8%. The bounding box it returns is a fixed centre box, not a real
  defect location.
